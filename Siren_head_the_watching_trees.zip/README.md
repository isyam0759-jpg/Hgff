# Siren Head: The Watching Trees (Forge 1.20.1 port)

Port Java Edition (Forge 1.20.1) dari addon Bedrock **Siren Head: The Watching Trees**.
**Wajib** memakai [GeckoLib](https://www.curseforge.com/minecraft/mc-mods/geckolib) 4.4.9+ untuk 1.20.1.

- Mod ID / namespace aset: `siren_head_the_watching_trees`
- Entity: `siren_head_the_watching_trees:siren_head`
- Spawn egg ada di tab Spawn Eggs. Spawn alami: Overworld, malam / gelap, sangat langka, hanya satu pada satu waktu.

## Build

Butuh JDK 17 (Gradle akan mencoba mengunduhnya sendiri bila belum ada) dan koneksi internet.

    ./gradlew build          # Windows: gradlew.bat build

Hasil: `build/libs/siren_head_the_watching_trees-1.0.0.jar`. Taruh di `mods/` bersama GeckoLib.
Untuk mencoba langsung: `./gradlew runClient`.

## Perilaku (diterjemahkan dari addon Bedrock)

| Bedrock | Port Forge |
|---|---|
| `sh:calm` | Fase CALM: berkeliling pelan, alarm berbunyi acak (`siren.alarms`). |
| `sh:pursuit` + `function run` | Fase PURSUIT: begitu menemukan pemain, jeritan + musik chase, kecepatan naik. |
| `timer`, `timer_2`, `timer_3` | Serangan acak STOMP / SMASH / SLAM (animasi `stomp`, `smash`, `slam`), dampak area + knockback + debu. |
| `sh:attack` knockback_roar | Diganti dampak area di `SirenHeadEntity.doImpact()`. |
| `break_blocks` | Menghancurkan blok lunak (kayu, daun, kaca, pintu, dst) di jalurnya (mengikuti gamerule `mobGriefing`). |
| `sh:dead` + `function dead` | Animasi `dies`, suara mati + `cool`, pesan "Congrats You Have Beaten The SIREN HEAD". |

Angka yang mudah diubah ada di bagian "tuning knobs" pada `SirenHeadEntity.java`
(darah, kecepatan, radius dan damage dampak, dll).

## Perbedaan dari versi Bedrock

- Darah maksimum 1024, bukan 900000: itu batas atribut vanilla. Satu pukulan dibatasi 40 damage.
- Partikel kustom Bedrock diganti partikel vanilla (debu blok + ledakan kecil).
- Camera shake, cuaca badai, dan efek speed ke semua pemain pada `run.mcfunction` tidak dibawa.
- Entity pembantu (`timer`, `timer_calm`, `timer_attack_select`, `attack`, `dead`, villager) tidak diperlukan; semuanya jadi satu entity.
- Gerak memakai jalan lurus ke target (bukan pathfinding vanilla), karena hitbox setinggi 42 blok membuat jalur vanilla hampir selalu dianggap terhalang.
- Nama folder aset/data harus huruf kecil (aturan Minecraft), jadi `siren_head_the_watching_trees`.
  Folder proyek tetap `Siren_head_the_watching_trees`.

## Kredit dan lisensi

Model, tekstur, animasi, dan suara berasal dari addon Bedrock oleh **Kyrie Guinto** (tim: VICH, ILYA HOVAL228, KYRIE GUINTO 3, DBZM).
Siren Head diciptakan oleh **Trevor Henderson**.
Lisensi asli addon ada di `credits/ORIGINAL_LICENSE_KYRIE_GUINTO.txt`: **dilarang mengunggah ulang atau membagikan**
tanpa izin pemilik. Port ini hanya untuk pemakaian pribadi.
