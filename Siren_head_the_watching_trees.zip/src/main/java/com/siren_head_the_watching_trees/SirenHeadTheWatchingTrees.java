package com.siren_head_the_watching_trees;

import com.siren_head_the_watching_trees.registry.ModEntities;
import com.siren_head_the_watching_trees.registry.ModItems;
import com.siren_head_the_watching_trees.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SirenHeadTheWatchingTrees.MOD_ID)
public class SirenHeadTheWatchingTrees {
    public static final String MOD_ID = "siren_head_the_watching_trees";

    public SirenHeadTheWatchingTrees() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
    }
}
