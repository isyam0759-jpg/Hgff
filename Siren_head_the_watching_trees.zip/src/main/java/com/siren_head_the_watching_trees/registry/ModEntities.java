package com.siren_head_the_watching_trees.registry;

import com.siren_head_the_watching_trees.SirenHeadTheWatchingTrees;
import com.siren_head_the_watching_trees.entity.SirenHeadEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SirenHeadTheWatchingTrees.MOD_ID);

    // Model is ~42 blocks tall (672 px) and ~6.4 blocks wide with arms out.
    public static final RegistryObject<EntityType<SirenHeadEntity>> SIREN_HEAD = ENTITIES.register("siren_head",
            () -> EntityType.Builder.of(SirenHeadEntity::new, MobCategory.MONSTER)
                    .sized(4.0F, 42.0F)
                    .clientTrackingRange(32)
                    .updateInterval(2)
                    .build("siren_head"));
}
