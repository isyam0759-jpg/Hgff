package com.siren_head_the_watching_trees.registry;

import com.siren_head_the_watching_trees.SirenHeadTheWatchingTrees;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SirenHeadTheWatchingTrees.MOD_ID);

    public static final RegistryObject<SoundEvent> ALARM = register("alarm", 256.0F);
    public static final RegistryObject<SoundEvent> CHASE = register("chase", 160.0F);
    public static final RegistryObject<SoundEvent> STOMP = register("stomp", 192.0F);
    public static final RegistryObject<SoundEvent> STEP = register("step", 128.0F);
    public static final RegistryObject<SoundEvent> DEAD = register("dead", 192.0F);
    public static final RegistryObject<SoundEvent> SCREAM = register("scream", 256.0F);
    public static final RegistryObject<SoundEvent> JUMPSCARE = register("jumpscare", 96.0F);
    public static final RegistryObject<SoundEvent> COOL = register("cool", 64.0F);

    private static RegistryObject<SoundEvent> register(String name, float range) {
        return SOUNDS.register(name, () -> SoundEvent.createFixedRangeEvent(
                new ResourceLocation(SirenHeadTheWatchingTrees.MOD_ID, name), range));
    }
}
