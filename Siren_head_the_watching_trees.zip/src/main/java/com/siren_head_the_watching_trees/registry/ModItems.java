package com.siren_head_the_watching_trees.registry;

import com.siren_head_the_watching_trees.SirenHeadTheWatchingTrees;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SirenHeadTheWatchingTrees.MOD_ID);

    public static final RegistryObject<Item> SIREN_HEAD_SPAWN_EGG = ITEMS.register("siren_head_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SIREN_HEAD, 0xEA9A51, 0xFF0909, new Item.Properties()));
}
