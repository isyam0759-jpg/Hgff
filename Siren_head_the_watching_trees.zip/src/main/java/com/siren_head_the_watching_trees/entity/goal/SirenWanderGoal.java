package com.siren_head_the_watching_trees.entity.goal;

import com.siren_head_the_watching_trees.entity.SirenHeadEntity;
import java.util.EnumSet;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.levelgen.Heightmap;

/** Slow idle wandering while calm (straight-line, same reason as the chase goal). */
public class SirenWanderGoal extends Goal {
    private final SirenHeadEntity siren;
    private double wx;
    private double wy;
    private double wz;
    private int timeout;

    public SirenWanderGoal(SirenHeadEntity siren) {
        this.siren = siren;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        return !this.siren.isPursuit() && this.siren.getTarget() == null
                && !this.siren.isDeadOrDying() && this.siren.getRandom().nextInt(100) == 0;
    }

    @Override
    public void start() {
        double angle = this.siren.getRandom().nextDouble() * Mth.TWO_PI;
        double dist = 12.0D + this.siren.getRandom().nextDouble() * 24.0D;
        this.wx = this.siren.getX() + Math.cos(angle) * dist;
        this.wz = this.siren.getZ() + Math.sin(angle) * dist;
        this.wy = this.siren.level().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Mth.floor(this.wx), Mth.floor(this.wz));
        this.timeout = 400;
    }

    @Override
    public boolean canContinueToUse() {
        if (this.siren.isPursuit() || this.siren.getTarget() != null || this.siren.isDeadOrDying() || --this.timeout <= 0) {
            return false;
        }
        double dx = this.wx - this.siren.getX();
        double dz = this.wz - this.siren.getZ();
        return dx * dx + dz * dz > 9.0D;
    }

    @Override
    public void tick() {
        this.siren.getMoveControl().setWantedPosition(this.wx, this.wy, this.wz, 0.6D);
    }
}
