package com.siren_head_the_watching_trees.entity.goal;

import com.siren_head_the_watching_trees.entity.SirenHeadEntity;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Walks straight at the target. Vanilla pathfinding is deliberately avoided: the hitbox is 42 blocks tall,
 * so almost no path would ever be "free". Obstacles are stepped over or smashed instead.
 */
public class SirenChaseGoal extends Goal {
    private final SirenHeadEntity siren;

    public SirenChaseGoal(SirenHeadEntity siren) {
        this.siren = siren;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = this.siren.getTarget();
        return this.siren.isPursuit() && target != null && target.isAlive() && !this.siren.isDeadOrDying();
    }

    @Override
    public boolean canContinueToUse() {
        return this.canUse();
    }

    @Override
    public void tick() {
        LivingEntity target = this.siren.getTarget();
        if (target == null) {
            return;
        }
        this.siren.getLookControl().setLookAt(target, 30.0F, 30.0F);
        double dx = target.getX() - this.siren.getX();
        double dz = target.getZ() - this.siren.getZ();
        if (dx * dx + dz * dz > 25.0D) {
            this.siren.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 1.0D);
        }
    }
}
