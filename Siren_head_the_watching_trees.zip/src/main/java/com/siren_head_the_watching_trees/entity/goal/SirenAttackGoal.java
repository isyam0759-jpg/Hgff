package com.siren_head_the_watching_trees.entity.goal;

import com.siren_head_the_watching_trees.entity.SirenHeadEntity;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/** Picks stomp / smash / slam, plays it out standing still and lands the hit at the right frame. */
public class SirenAttackGoal extends Goal {
    private final SirenHeadEntity siren;
    private int type;
    private int ticks;

    public SirenAttackGoal(SirenHeadEntity siren) {
        this.siren = siren;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = this.siren.getTarget();
        if (target == null || !target.isAlive() || !this.siren.canStartAttack()) {
            return false;
        }
        double dx = target.getX() - this.siren.getX();
        double dz = target.getZ() - this.siren.getZ();
        return dx * dx + dz * dz <= SirenHeadEntity.ATTACK_START_RANGE * SirenHeadEntity.ATTACK_START_RANGE;
    }

    @Override
    public boolean canContinueToUse() {
        return !this.siren.isDeadOrDying() && this.ticks < SirenHeadEntity.ATTACK_LENGTH[this.type];
    }

    @Override
    public void start() {
        this.type = 1 + this.siren.getRandom().nextInt(3);
        this.ticks = 0;
        this.siren.getNavigation().stop();
        this.siren.beginAttack(this.type);
    }

    @Override
    public void tick() {
        this.ticks++;
        LivingEntity target = this.siren.getTarget();
        if (target != null && this.ticks < SirenHeadEntity.ATTACK_IMPACT[this.type]) {
            this.siren.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }
        if (this.ticks == SirenHeadEntity.ATTACK_IMPACT[this.type]) {
            this.siren.doImpact();
        }
    }

    @Override
    public void stop() {
        this.siren.finishAttack();
    }
}
