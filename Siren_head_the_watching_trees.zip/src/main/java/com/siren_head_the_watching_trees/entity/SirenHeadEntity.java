package com.siren_head_the_watching_trees.entity;

import com.siren_head_the_watching_trees.entity.goal.SirenAttackGoal;
import com.siren_head_the_watching_trees.entity.goal.SirenChaseGoal;
import com.siren_head_the_watching_trees.entity.goal.SirenWanderGoal;
import com.siren_head_the_watching_trees.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ForgeEventFactory;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Siren Head. Two phases like the original addon:
 * CALM (wanders, blares the alarm now and then) and PURSUIT (fast chase + stomp / smash / slam attacks).
 */
public class SirenHeadEntity extends Monster implements GeoEntity {

    // ---- tuning knobs ------------------------------------------------------------------------
    public static final double MAX_HEALTH = 1024.0D;          // vanilla attribute cap is 1024
    public static final double CALM_SPEED = 0.30D;            // blocks/tick-ish, wander uses x0.6
    public static final double PURSUIT_SPEED = 0.50D;
    public static final double CALM_FOLLOW_RANGE = 64.0D;
    public static final double PURSUIT_FOLLOW_RANGE = 100.0D;
    public static final float MAX_DAMAGE_PER_HIT = 40.0F;     // stops one-shotting the boss
    public static final double ATTACK_START_RANGE = 16.0D;    // horizontal distance to begin an attack
    public static final double IMPACT_RADIUS = 16.0D;
    public static final float IMPACT_DAMAGE = 24.0F;          // at the centre, falls off to ~40%
    public static final int PURSUIT_LOSE_TICKS = 300;         // 15 s without a target -> calm again

    public static final int ATTACK_NONE = 0;
    public static final int ATTACK_STOMP = 1;
    public static final int ATTACK_SMASH = 2;
    public static final int ATTACK_SLAM = 3;
    /** Animation lengths in ticks (3.0s, 3.012s, 2.5s). */
    public static final int[] ATTACK_LENGTH = {0, 60, 61, 50};
    /** Tick inside the animation at which the hit lands. */
    public static final int[] ATTACK_IMPACT = {0, 30, 26, 22};

    // ---- synced state ------------------------------------------------------------------------
    private static final EntityDataAccessor<Boolean> DATA_PURSUIT =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_ATTACK =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.INT);

    // ---- animations --------------------------------------------------------------------------
    private static final RawAnimation ANIM_IDLE = RawAnimation.begin().thenLoop("animation.sh.idle");
    private static final RawAnimation ANIM_WALK = RawAnimation.begin().thenLoop("animation.sh.walk");
    private static final RawAnimation ANIM_PURSUIT = RawAnimation.begin().thenLoop("animation.sh.pursuit");
    private static final RawAnimation ANIM_DIES = RawAnimation.begin().thenPlayAndHold("animation.sh.dies");
    private static final RawAnimation ANIM_STOMP = RawAnimation.begin()
            .then("animation.sh.stomp", Animation.LoopType.PLAY_ONCE).thenLoop("animation.sh.idle");
    private static final RawAnimation ANIM_SMASH = RawAnimation.begin()
            .then("animation.sh.smash", Animation.LoopType.PLAY_ONCE).thenLoop("animation.sh.idle");
    private static final RawAnimation ANIM_SLAM = RawAnimation.begin()
            .then("animation.sh.slam", Animation.LoopType.PLAY_ONCE).thenLoop("animation.sh.idle");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private int attackCooldown = 0;
    private int lostTargetTicks = 0;
    private int alarmTimer;

    public SirenHeadEntity(EntityType<? extends SirenHeadEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setMaxUpStep(2.5F);
        this.setPersistenceRequired();
        this.alarmTimer = 600 + this.random.nextInt(1200);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, CALM_SPEED)
                .add(Attributes.FOLLOW_RANGE, CALM_FOLLOW_RANGE)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ARMOR, 10.0D);
    }

    public static boolean checkSirenSpawnRules(EntityType<SirenHeadEntity> type, ServerLevelAccessor level,
                                               MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (!Monster.checkMonsterSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        if (reason == MobSpawnType.SPAWNER) {
            return true;
        }
        if (random.nextInt(6) != 0) {
            return false; // very rare
        }
        // only one around at a time
        AABB area = new AABB(pos).inflate(300.0D);
        return level.getLevel().getEntitiesOfClass(SirenHeadEntity.class, area).isEmpty();
    }

    // ---- AI ----------------------------------------------------------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new SirenAttackGoal(this));
        this.goalSelector.addGoal(2, new SirenChaseGoal(this));
        this.goalSelector.addGoal(3, new SirenWanderGoal(this));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 48.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();

        LivingEntity target = this.getTarget();
        boolean hasTarget = target != null && target.isAlive();

        if (hasTarget) {
            this.lostTargetTicks = 0;
            if (!this.isPursuit()) {
                this.startPursuit();
            }
        } else if (this.isPursuit() && ++this.lostTargetTicks > PURSUIT_LOSE_TICKS) {
            this.endPursuit();
        }

        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }

        if (!this.isPursuit()) {
            if (--this.alarmTimer <= 0) {
                this.broadcastSound(ModSounds.ALARM.get(), 256.0D, 1.0F);
                this.alarmTimer = 3000 + this.random.nextInt(3000);
            }
        } else if (this.tickCount % 5 == 0) {
            this.breakBlocksInPath();
        }
    }

    // ---- phases ------------------------------------------------------------------------------
    public boolean isPursuit() {
        return this.entityData.get(DATA_PURSUIT);
    }

    private void startPursuit() {
        this.entityData.set(DATA_PURSUIT, true);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(PURSUIT_SPEED);
        this.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(PURSUIT_FOLLOW_RANGE);
        this.attackCooldown = 40;
        this.broadcastSound(ModSounds.SCREAM.get(), 160.0D, 1.0F);
        this.broadcastSound(ModSounds.CHASE.get(), 160.0D, 1.0F);
    }

    private void endPursuit() {
        this.entityData.set(DATA_PURSUIT, false);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(CALM_SPEED);
        this.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(CALM_FOLLOW_RANGE);
        this.alarmTimer = 1200 + this.random.nextInt(1200);
        this.stopChaseMusic();
    }

    private void stopChaseMusic() {
        if (this.level() instanceof ServerLevel server) {
            ClientboundStopSoundPacket packet = new ClientboundStopSoundPacket(ModSounds.CHASE.getId(), SoundSource.HOSTILE);
            for (ServerPlayer player : server.players()) {
                player.connection.send(packet);
            }
        }
    }

    // ---- attacks -----------------------------------------------------------------------------
    public int getAttackType() {
        return this.entityData.get(DATA_ATTACK);
    }

    public boolean canStartAttack() {
        return this.isPursuit() && this.attackCooldown <= 0 && this.getAttackType() == ATTACK_NONE && !this.isDeadOrDying();
    }

    public void beginAttack(int type) {
        this.entityData.set(DATA_ATTACK, type);
        LivingEntity target = this.getTarget();
        if (target instanceof ServerPlayer player) {
            player.playNotifySound(ModSounds.JUMPSCARE.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    public void finishAttack() {
        this.entityData.set(DATA_ATTACK, ATTACK_NONE);
        this.attackCooldown = 60 + this.random.nextInt(60);
    }

    /** The moment the foot / fists land: damage, knockback, dust and sound. */
    public void doImpact() {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        this.playSound(ModSounds.STOMP.get(), 12.0F, 1.0F);

        AABB box = new AABB(this.getX() - IMPACT_RADIUS, this.getY() - 4.0D, this.getZ() - IMPACT_RADIUS,
                this.getX() + IMPACT_RADIUS, this.getY() + 12.0D, this.getZ() + IMPACT_RADIUS);
        for (LivingEntity victim : server.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != this && e.isAlive() && !(e instanceof SirenHeadEntity))) {
            double dx = victim.getX() - this.getX();
            double dz = victim.getZ() - this.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > IMPACT_RADIUS) {
                continue;
            }
            float damage = (float) (IMPACT_DAMAGE * (1.0D - 0.6D * dist / IMPACT_RADIUS));
            victim.hurt(this.damageSources().mobAttack(this), damage);
            victim.knockback(1.8D, this.getX() - victim.getX(), this.getZ() - victim.getZ());
            victim.setDeltaMovement(victim.getDeltaMovement().add(0.0D, 0.5D, 0.0D));
            victim.hurtMarked = true;
        }

        BlockState ground = this.level().getBlockState(this.blockPosition().below());
        if (ground.isAir()) {
            ground = Blocks.DIRT.defaultBlockState();
        }
        BlockParticleOption dust = new BlockParticleOption(ParticleTypes.BLOCK, ground);
        for (int ring = 1; ring <= 4; ring++) {
            double radius = ring * 3.5D;
            int count = 14 + ring * 6;
            for (int i = 0; i < count; i++) {
                double angle = Mth.TWO_PI * i / count;
                server.sendParticles(dust, this.getX() + Math.cos(angle) * radius, this.getY() + 0.3D,
                        this.getZ() + Math.sin(angle) * radius, 3, 0.4D, 0.2D, 0.4D, 0.15D);
            }
        }
        server.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 0.5D, this.getZ(), 6, 3.0D, 0.5D, 3.0D, 0.0D);
    }

    /** Smashes soft blocks (logs, leaves, planks, glass, doors...) the giant walks into. */
    private void breakBlocksInPath() {
        if (!ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            return;
        }
        AABB box = this.getBoundingBox().inflate(0.6D, 0.0D, 0.6D);
        int broken = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = Mth.floor(box.minX); x <= Mth.floor(box.maxX); x++) {
            for (int z = Mth.floor(box.minZ); z <= Mth.floor(box.maxZ); z++) {
                for (int y = Mth.floor(box.minY); y <= Mth.floor(box.maxY); y++) {
                    pos.set(x, y, z);
                    BlockState state = this.level().getBlockState(pos);
                    if (state.isAir() || !state.getFluidState().isEmpty()) {
                        continue;
                    }
                    float hardness = state.getDestroySpeed(this.level(), pos);
                    if (hardness < 0.0F || hardness > 5.0F) {
                        continue;
                    }
                    this.level().destroyBlock(pos, false, this);
                    if (++broken >= 300) {
                        return;
                    }
                }
            }
        }
    }

    // ---- sound helpers -----------------------------------------------------------------------
    /** Plays a sound at each nearby player's own position so distance does not fade it (like Bedrock's playsound @a). */
    private void broadcastSound(SoundEvent sound, double range, float volume) {
        if (this.level() instanceof ServerLevel server) {
            for (ServerPlayer player : server.players()) {
                if (player.distanceToSqr(this) <= range * range) {
                    player.playNotifySound(sound, SoundSource.HOSTILE, volume, 1.0F);
                }
            }
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(ModSounds.STEP.get(), 6.0F, 1.0F);
    }

    // ---- death -------------------------------------------------------------------------------
    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide() && !this.isDeadOrDying()) {
            this.stopChaseMusic();
            this.broadcastSound(ModSounds.DEAD.get(), 192.0D, 1.0F);
            this.broadcastSound(ModSounds.COOL.get(), 192.0D, 1.0F);
            if (this.level() instanceof ServerLevel server) {
                Component message = Component.literal("Congrats ").withStyle(net.minecraft.ChatFormatting.GREEN)
                        .append(Component.literal("You Have Beaten The ").withStyle(net.minecraft.ChatFormatting.WHITE))
                        .append(Component.literal("SIREN HEAD").withStyle(net.minecraft.ChatFormatting.DARK_RED));
                for (ServerPlayer player : server.players()) {
                    if (player.distanceToSqr(this) <= 300.0D * 300.0D) {
                        player.sendSystemMessage(message);
                    }
                }
            }
        }
        super.die(source);
    }

    /** Keep the corpse around for the whole 5.4 s "dies" animation. */
    @Override
    protected void tickDeath() {
        ++this.deathTime;
        if (this.deathTime >= 110 && !this.level().isClientSide() && !this.isRemoved()) {
            this.level().broadcastEntityEvent(this, (byte) 60);
            this.remove(RemovalReason.KILLED);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return super.hurt(source, Math.min(amount, MAX_DAMAGE_PER_HIT));
    }

    // ---- misc overrides ----------------------------------------------------------------------
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_PURSUIT, false);
        this.entityData.define(DATA_ATTACK, ATTACK_NONE);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return 38.0F;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ---- GeckoLib ----------------------------------------------------------------------------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 5, this::animationPredicate));
    }

    private PlayState animationPredicate(AnimationState<SirenHeadEntity> state) {
        SirenHeadEntity siren = state.getAnimatable();
        if (siren.isDeadOrDying()) {
            return state.setAndContinue(ANIM_DIES);
        }
        switch (siren.getAttackType()) {
            case ATTACK_STOMP:
                return state.setAndContinue(ANIM_STOMP);
            case ATTACK_SMASH:
                return state.setAndContinue(ANIM_SMASH);
            case ATTACK_SLAM:
                return state.setAndContinue(ANIM_SLAM);
            default:
                break;
        }
        if (state.isMoving()) {
            return state.setAndContinue(siren.isPursuit() ? ANIM_PURSUIT : ANIM_WALK);
        }
        return state.setAndContinue(ANIM_IDLE);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
