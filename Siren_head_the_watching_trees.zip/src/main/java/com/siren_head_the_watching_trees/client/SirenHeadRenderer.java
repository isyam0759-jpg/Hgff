package com.siren_head_the_watching_trees.client;

import com.siren_head_the_watching_trees.entity.SirenHeadEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SirenHeadRenderer extends GeoEntityRenderer<SirenHeadEntity> {
    public SirenHeadRenderer(EntityRendererProvider.Context context) {
        super(context, new SirenHeadModel());
        this.shadowRadius = 3.0F;
    }

    /** The "dies" animation already handles the fall, so don't also tip the entity over. */
    @Override
    protected float getDeathMaxRotation(SirenHeadEntity animatable) {
        return 0.0F;
    }
}
