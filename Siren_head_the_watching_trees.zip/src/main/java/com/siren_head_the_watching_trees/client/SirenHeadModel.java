package com.siren_head_the_watching_trees.client;

import com.siren_head_the_watching_trees.SirenHeadTheWatchingTrees;
import com.siren_head_the_watching_trees.entity.SirenHeadEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SirenHeadModel extends GeoModel<SirenHeadEntity> {
    private static final ResourceLocation MODEL =
            new ResourceLocation(SirenHeadTheWatchingTrees.MOD_ID, "geo/entity/siren_head.geo.json");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SirenHeadTheWatchingTrees.MOD_ID, "textures/entity/siren_head.png");
    private static final ResourceLocation ANIMATION =
            new ResourceLocation(SirenHeadTheWatchingTrees.MOD_ID, "animations/entity/siren_head.animation.json");

    @Override
    public ResourceLocation getModelResource(SirenHeadEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(SirenHeadEntity animatable) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(SirenHeadEntity animatable) {
        return ANIMATION;
    }
}
